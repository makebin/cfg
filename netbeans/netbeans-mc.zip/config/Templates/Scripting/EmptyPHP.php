<?php

<#assign licenseFirst = "/* ">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/**
 * @filename ${nameAndExt} 
 * @encoding ${encoding} 
 * @author ${user}
 * @datetime ${date} ${time}
 */